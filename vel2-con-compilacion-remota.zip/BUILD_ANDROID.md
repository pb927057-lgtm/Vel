# Compilar VEL Android sin instalar Android Studio en la computadora

Este proyecto incluye `.github/workflows/build-android.yml`, un flujo de GitHub Actions para intentar compilar la aplicación Android y ejecutar sus pruebas unitarias en un entorno remoto.

## Qué hace

1. Usa Java 17 y Gradle 8.10.2.
2. Instala Android SDK 35.
3. Ejecuta `testDebugUnitTest` y `assembleDebug`.
4. Si ambos pasos terminan correctamente, publica `app-debug.apk` como artefacto descargable de la ejecución.

## Cómo utilizarlo

1. Crea un repositorio en GitHub y sube el contenido completo de este proyecto, conservando las carpetas `android-vel`, `server-vel`, `src` y `.github`.
2. En el repositorio, abre **Actions**.
3. Selecciona **VEL Android build** y pulsa **Run workflow**. También se ejecuta cuando se suben cambios a `android-vel/`.
4. Abre la ejecución y revisa el resultado de **Compile and run Android unit tests**.
5. Solo si la ejecución termina correctamente, en **Artifacts** aparecerá `vel-debug-apk`; descárgalo para obtener el APK de depuración.

## Limitaciones importantes

- Este flujo todavía no ha sido ejecutado. Su presencia no demuestra que el proyecto compile.
- No se genera un APK de producción firmado.
- Las pruebas unitarias no sustituyen una prueba en dos teléfonos Android reales.
- No subas claves privadas, contraseñas, tokens de producción ni otros secretos al repositorio.
- GitHub puede solicitar que inicies sesión y confirmes la creación del repositorio. Revisa las condiciones y límites actuales de GitHub Actions antes de usarlo; este documento no garantiza una cuota gratuita específica.
